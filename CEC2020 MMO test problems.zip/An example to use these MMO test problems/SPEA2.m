%
% Copyright (c) 2015, Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "license.txt" for license terms.
%
% Project Code: YOEA122
% Project Title: Strength Pareto Evolutionary Algorithm 2 (SPEA2)
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: S. Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
%

function [ps,pf]=SPEA2(fname,xl,xu,nArchive,MaxIt)

%% Problem Definition


nVar=size(xl,2);               %Obtain the dimensions of decision space

VarMin=xl;           % Decision Variables Lower Bound  % ��VarMin=xl'�ĳ���VarMin=xl;��2018.7.3.23.05��;   
VarMax=xu;           % Decision Variables Upper Bound  % ��VarMax=xu���ĳ���VarMax=xu;��2018.7.3.23.05��; 


%% SPEA2 Settings
nPop=nArchive;            % Population Size


K=round(sqrt(nPop+nArchive));  % KNN Parameter

pCrossover=0.7;
nCrossover=round(pCrossover*nPop/2)*2;

pMutation=1-pCrossover;
nMutation=nPop-nCrossover;

crossover_params.gamma=0.1;
crossover_params.VarMin=VarMin;
crossover_params.VarMax=VarMax;

mutation_params.h=0.2;
mutation_params.VarMin=VarMin;
mutation_params.VarMax=VarMax;

%% Initialization

empty_individual.Position=[];
empty_individual.Cost=[];
empty_individual.S=[];
empty_individual.R=[];
empty_individual.sigma=[];
empty_individual.sigmaK=[];
empty_individual.D=[];
empty_individual.F=[];

pop=repmat(empty_individual,nPop,1);
for i=1:nPop
    pop(i).Position=VarMin+(VarMax-VarMin).*rand(1,nVar);% ��rand(nVar,1)�ĳ�rand(1��nVar)��2018.7.3.23.08��;
    pop(i).Cost=feval(fname,pop(i).Position);
end

archive=[];

%% Main Loop

for it=1:MaxIt
    
    Q=[pop
       archive];
    
    nQ=numel(Q);
    
    dom=false(nQ,nQ);
    
    for i=1:nQ
        Q(i).S=0;
    end
    
    for i=1:nQ
        for j=i+1:nQ
            
            if Dominates(Q(i),Q(j))
                Q(i).S=Q(i).S+1;
                dom(i,j)=true;
                
            elseif Dominates(Q(j),Q(i))
                Q(j).S=Q(j).S+1;
                dom(j,i)=true;
                
            end
            
        end
    end
    
    S=[Q.S];
    for i=1:nQ
        Q(i).R=sum(S(dom(:,i)));
    end
    
    Z=[Q.Cost]';
    SIGMA=pdist2(Z,Z,'seuclidean');
    SIGMA=sort(SIGMA);
    for i=1:nQ
        Q(i).sigma=SIGMA(:,i);
        Q(i).sigmaK=Q(i).sigma(K);
        Q(i).D=1/(Q(i).sigmaK+2);
        Q(i).F=Q(i).R+Q(i).D;
    end
    
    nND=sum([Q.R]==0);
    if nND<=nArchive
        F=[Q.F];
        [F, SO]=sort(F);
        Q=Q(SO);
        archive=Q(1:min(nArchive,nQ));
        
    else
        SIGMA=SIGMA(:,[Q.R]==0);
        archive=Q([Q.R]==0);
        
        k=2;
        while numel(archive)>nArchive
            while min(SIGMA(k,:))==max(SIGMA(k,:)) && k<size(SIGMA,1)
                k=k+1;
            end
            
            [~, j]=min(SIGMA(k,:));
            
            archive(j)=[];
            SIGMA(:,j)=[];
        end
        
    end
    
    PF=archive([archive.R]==0); % Approximate Pareto Front
    
   
    
    % Display Iteration Information
%     disp(['SPEA2  gen=  ' num2str(it) ]);
    
    if it>=MaxIt
        break;
    end
    
    % Crossover
    popc=repmat(empty_individual,nCrossover/2,2);
    for c=1:nCrossover/2
        
        p1=BinaryTournamentSelection(archive,[archive.F]);
        p2=BinaryTournamentSelection(archive,[archive.F]);
        
        [popc(c,1).Position, popc(c,2).Position]=Crossover(p1.Position,p2.Position,crossover_params);
        
        popc(c,1).Cost=feval(fname,popc(c,1).Position);
        popc(c,2).Cost=feval(fname,popc(c,2).Position);
        
    end
    popc=popc(:);
    
    % Mutation
    popm=repmat(empty_individual,nMutation,1);
    for m=1:nMutation
        
        p=BinaryTournamentSelection(archive,[archive.F]);
        
        popm(m).Position=Mutate(p.Position,mutation_params);
        
        popm(m).Cost=feval(fname,popm(m).Position);
        
    end
    
    % Create New Population
    pop=[popc
         popm];
    
end

%% Results

%**������2018.7.7.18.00 ������ʱȡ����ps��pf��1*popsize*ά�ȶ�����popsize*ά�ȵ����
if size(PF(1).Position,1)==1 %����Ա���������1
     ps=cat(1,PF.Position);
else
    ps=cat(2,PF.Position);
    ps=ps';
end

if size(PF(1).Cost,1)==1 %���Ŀ��ֵ������ά�ȣ�������1
    pf=cat(1,PF.Cost);
else
    pf=cat(2,PF.Cost);
    pf=pf';
end
%**end ������2018.7.7.18.00

% ps=[PF.Position];%ɾ����2018.7.7.18.00
% pf=[PF.Cost];
% ps=ps';
% pf=pf';
end

function b=Dominates(x,y)

    if isstruct(x) && isfield(x,'Cost')
        x=x.Cost;
    end

    if isstruct(y) && isfield(y,'Cost')
        y=y.Cost;
    end

    b=all(x<=y) && any(x<y);
    
end

function [y1, y2]=Crossover(x1,x2,params)

    gamma=params.gamma;
    VarMin=params.VarMin;
    VarMax=params.VarMax;
    
    alpha=unifrnd(-gamma,1+gamma,size(x1));
    
    y1=alpha.*x1+(1-alpha).*x2;
    y2=alpha.*x2+(1-alpha).*x1;
    
    y1=min(max(y1,VarMin),VarMax);
    y2=min(max(y2,VarMin),VarMax);

end

function p=BinaryTournamentSelection(pop,f)

    n=numel(pop);
    
    I=randsample(n,2);
    
    i1=I(1);
    i2=I(2);
    
    if f(i1)<f(i2)
        p=pop(i1);
    else
        p=pop(i2);
    end

end
function y=Mutate(x,params)

    h=params.h;
    VarMin=params.VarMin;
    VarMax=params.VarMax;
    nVar=length(x);
    y=zeros(size(x));
    for i=1:nVar
    sigma=h*(VarMax(i)-VarMin(i));
    
    y(i)=x(i)+sigma*randn;
    end
    
    % y=x+sigma*unifrnd(-1,1,size(x));
    
    y=min(max(y,VarMin),VarMax);

end

